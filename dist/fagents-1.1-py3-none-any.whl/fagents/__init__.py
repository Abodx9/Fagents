from .fagents import xrand, Mac, opera, mobile, linux, win, unix
